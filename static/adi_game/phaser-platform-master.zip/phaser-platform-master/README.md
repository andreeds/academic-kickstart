# phaser-platform

![phaser-platform](https://raw.github.com/felipepucinelli/phaser-platform/master/demo.jpg)

A platform game developed with phaser.io

[Play the game](http://felipepucinelli.github.io/phaser-platform/)